#include <stdio.h>

int main(void) 
{
    float nota1, nota2, nota3, media = 0;

    printf("Informe a nota 1: ");
    scanf("%f", &nota1);
    printf("Informe a nota 2: ");
    scanf("%f", &nota2);
    media = (nota1 + nota2) / 2;
    printf("Média: %.2f\n", media);

    // Condição para verificar se o aluno foi aprovado diretamente
    if (media >= 7) 
    {
        printf("Aluno Aprovado = %.2f\n");
    }
    // Condição para verificar se o aluno foi reprovado diretamente
    else if (media <= 4.9)
    {
        printf("Aluno Reprovado sem direito a Recuperacao:  %.2f\n");
    }
    // Caso o aluno não seja aprovado nem reprovado diretamente, ele terá que fazer recuperacao
    else
    {
        printf("Aluno em Recuperação\n");
        printf("Informe a nota da Recuperação: ");
        scanf("%f", &nota3);

        // Calculando a nova média após a recuperação
        if (nota1 > nota2)
            media = (nota1 + nota3) / 2;
        else
            media = (nota2 + nota3) / 2;

        // Verificando se o aluno passou ou não após a recuperação
        if (media >= 7)
        {
            printf("\nMédia após Recuperação: %.2f\n", media);
            printf("Aluno Aprovado após Recuperação\n");
        } 
        else 
        {
            printf("\nMédia após Recuperação: %.2f\n", media);
            printf("Aluno Reprovado após Recuperação\n");
        }
    }

    return 0;
}